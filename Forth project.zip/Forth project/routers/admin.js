const router=require('express').Router()
const Regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc=require('../controllers/querycontroller')
const addc=require('../controllers/addcontroller')
const multer=require('multer')


let storage=multer.diskStorage({
    destination:function(req,file,cb)
    {
         cb(null,'./public/upload')
    },
    filename:function(req,file,cb)
    {
        cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})




router.get('/',Regc.adminloginshow)
router.post('/loginrecord',Regc.adminlogincheck)
router.get('/dashboard',Regc.admindashboardshow)
router.get('/banner',bannerc.bannershow)
router.get('/logout',Regc.logout)
router.get('/bannerupdate/:id',bannerc.bannerupdatepage)
router.post('/bannerupdaterecord/:id',upload.single('img'),bannerc.bannerupdate)
router.get('/service',servicec.serviceshow)
router.get('/serviceadd',servicec.serviceAdd)
router.post('/serviceaddrecord',upload.single('img'),servicec.serviceinsert)
router.get('/servicestatusupdate/:id',servicec.servicestatusupdate)
router.get('/servicedelete/:id',servicec.servicedelete)
router.post('/servicesearch',servicec.servicesearch)
router.get('/testi',testic.testishow)
router.get('/status/:id',testic.status)
router.post('/testisearch',testic.testisearch)
router.get('/query',queryc.queryshow)
router.get('/queryreply/:id',queryc.queryreply)
router.post('/replyrecord/:id',upload.single('attachment'),queryc.replyrecord)
router.get('/add',addc.addshow)
router.get('/addupdate/:id',addc.addupdate)
router.post('/addupdaterecord/:id',addc.addupdaterecord)
















module.exports=router