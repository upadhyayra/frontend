const router=require('express').Router()
const bannerc=require('../controllers/bannercontroller')
const Banner=require('../models/banner')
const Services=require('../models/services')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const Testi=require('../models/testi')
const queryc=require('../controllers/querycontroller')
const Query=require('../models/query')
const Address=require('../models/address')
const multer=require('multer')
let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})


let upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})




router.get('/',async(req,res)=>{
    const record=await Banner.findOne()
    const serviceRecord=await Services.find({status:'publish'})
    const testirecord=await Testi.find({status:'publish'})
    const addrecord=await Address.findOne()

    res.render('index.ejs',{record,serviceRecord,testirecord,addrecord})
})

router.get('/banner',bannerc.banner)
router.get('/service/:id',servicec.frontendservice)
router.get('/testiform',testic.testiform)
router.post('/testirecord',upload.single('img'),testic.testinsert)
router.post('/queryform',queryc.queryform)















module.exports=router