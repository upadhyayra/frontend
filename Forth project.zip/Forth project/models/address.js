const mongoose=require('mongoose')
const addSchema=mongoose.Schema({
    name:String,
    add:String,
    landline:Number,
    mobile:Number,
    email:String,
    insta:String,
    twitter:String,
    link:String 
    
    

})
module.exports=mongoose.model('address',addSchema)