const Query=require('../models/query')
const nodemailer=require('nodemailer')

exports.queryform=async(req,res)=>{
    const{email,query}=req.body
   const record=await new Query({email:email,query:query})
   record.save()
   res.redirect('/')
}
exports.queryshow=async(req,res)=>{
const record=await Query.find()
    res.render('admin/query.ejs',{record})
}
exports.queryreply=async(req,res)=>{
    
    const id=req.params.id
    const record=await Query.findById(id)
    
    res.render('admin/queryreplyform.ejs',{record})
}
exports.replyrecord=async(req,res)=>{
    const id=req.params.id
    const path=req.file.path
    // console.log(req.body)
    const{emailto,emailfrom,subject,body}=req.body

    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user:'rahulshr8949@gmail.com', // generated ethereal user
        pass:'mjcypijsqmkqfsbg', // generated ethereal password
      },
    });
    console.log('connected to smtp server')
    let info = await transporter.sendMail({
        from:emailfrom, // sender address
        to:emailto, // list of receivers
        subject: subject, // Subject line
        text:body, // plain text body
        // html: "<b>Hello world?</b>", // html body
        attachments:    [{
            path:path
        }]
      });
      console.log('sent mail')
      await Query.findByIdAndUpdate(id,{status:'Replied'})
  res.redirect('/admin/query')


}