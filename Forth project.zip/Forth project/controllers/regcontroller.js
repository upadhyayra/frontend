const Reg=require('../models/reg')


exports.adminloginshow=(req,res)=>{
    res.render('admin/login.ejs')
}
exports.adminlogincheck=async(req,res)=>{
    // console.log(req.body)
    const{username,password}=req.body
    const record=await Reg.findOne({username:username})
    if(record!==null)
    {
        if(record.password==password)
        {
            res.redirect('/admin/dashboard')
        }

        else
        {
            res.redirect('/admin/')
        }

    }
    else{
        res.redirect('/admin/')
    }
}
exports.admindashboardshow=(req,res)=>{
    res.render('admin/dashboard.ejs')
}
exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/admin/')
}