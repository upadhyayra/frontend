
const Add=require('../models/address')





exports.addshow=async(req,res)=>{
const record=await Add.findOne()
    res.render('admin/add.ejs',{record})
}
exports.addupdate=async(req,res)=>{
    const id=req.params.id
    const record=await Add.findById(id)
    res.render('admin/addform',{record})
}
exports.addupdaterecord=async(req,res)=>{
    const id=req.params.id
    const{name,add,landline,mobile,email,insta,twitter,link}=req.body

    await Add.findByIdAndUpdate(id,{name:name,add:add,landline:landline,mobile:mobile,email:email,insta:insta,twitter:twitter,link:link})
    res.redirect('/')
    
}
