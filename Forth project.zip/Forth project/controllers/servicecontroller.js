const Services=require('../models/services')
const Add=require('../models/address')



exports.serviceshow=async(req,res)=>{
const record=await Services.find().sort({postedDate:-1})
const servicecount=await Services.count()
const publishcount=await Services.count({status:'publish'})
const unpublishcount=await Services.count({status:'unpublish'})



    res.render('admin/service.ejs',{record,servicecount,publishcount,unpublishcount})
}
exports.serviceAdd=(req,res)=>{


    res.render('admin/serviceadd.ejs')
}
exports.serviceinsert=async(req,res)=>{
    const filename=req.file.filename
    const{name,desc,ldesc}=req.body
    const record=await new  Services({name:name,desc:desc,ldesc:ldesc,img:filename})
        record.save()
        // console.log(record)
        res.redirect('/admin/service')
        
       


}
exports.servicestatusupdate=async(req,res)=>{
    const id=req.params.id
    const record=await Services.findById(id)
    let newstatus=null
    if(record.status=='unpublish')
    {
        newstatus='publish'
    }
    else
    {
        newstatus='unpublish'
    }
    await Services.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/service')

}
exports.frontendservice=async(req,res)=>{
    const id=req.params.id
    const record=await Services.findById(id)
    const addrecord=await Add.findOne()
   
    res.render('services.ejs',{record,addrecord})
}
exports.servicedelete=async(req,res)=>{
    const id=req.params.id
    const record=await Services.findByIdAndDelete(id)
    res.redirect('/admin/service')
}
exports.servicesearch=async(req,res)=>{
    const{search}=req.body
    const record=await Services.find({status:search})
    const servicecount=await Services.count()
const publishcount=await Services.count({status:'publish'})
const unpublishcount=await Services.count({status:'unpublish'})
    res.render('admin/service.ejs',{record,servicecount,publishcount,unpublishcount})

}