const Testi=require('../models/testi')
const Add=require('../models/address')



exports.testishow=async(req,res)=>{
    const record=await Testi.find()
    
    const testicount=await Testi.count()
    const publishcount=await Testi.count({status:'publish'})
    const unpublishcount=await Testi.count({status:'unpublish'})
    res.render('admin/testi.ejs',{record,testicount,publishcount,unpublishcount})
}
exports.testiform=async(req,res)=>{
    const addrecord=await Add.findOne()
    res.render('testiform.ejs',{addrecord})
}
exports.testinsert=async(req,res)=>{
    const filename=req.file.filename
    const{quotes,name}=req.body
     const record=await new Testi({quotes:quotes,name:name,img:filename})
     console.log(record)
     record.save()
     res.redirect('/')
}
exports.status=async(req,res)=>{
    const id=req.params.id
    const record=await Testi.findById(id)
    let newstatus=null
    if(record.status=='unpublish'){
        newstatus='publish'


    }
    else{
        newstatus='unpublish'
    }
    await Testi.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/testi')
}

exports.testisearch=async(req,res)=>{
    // console.log(req.body)
    const{search}=req.body
    const record=await Testi.find({status:search})
    const testicount=await Testi.count()
    const publishcount=await Testi.count({status:'publish'})
    const unpublishcount=await Testi.count({status:'unpublish'})
    res.render('admin/testi',{record,testicount,publishcount,unpublishcount})

}